function draw2DIV(){
	var js_input_1 = document.getElementById('html_input_1').value;
	var js_input_2 = document.getElementById('html_input_2').value;
	var js_input_3 = document.getElementById('html_input_3').value;
	var js_input_4 = document.getElementById('html_input_4').value;

	document.getElementById('output_display').innerHTML = 'Input 1: ' + js_input_1 + '<br>Input 2: ' + js_input_2 + '<br>Input 3: ' + js_input_3 + '<br>Input 4: ' + js_input_4;
}