function changeColor(){
	//fill in the missing ID
	var newColor = document.getElementById().value;
	//set the background color of the button to newColor
	document.getElementById().
}

function showMessage(){
	//fill in the missing ID
	var message = document.getElementById().value;
	//alert message
	
}